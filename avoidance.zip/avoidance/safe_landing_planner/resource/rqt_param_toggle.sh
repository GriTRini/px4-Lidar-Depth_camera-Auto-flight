#!/bin/bash

rosrun dynamic_reconfigure dynparam set /camera_main_node depth_range_mode 3
