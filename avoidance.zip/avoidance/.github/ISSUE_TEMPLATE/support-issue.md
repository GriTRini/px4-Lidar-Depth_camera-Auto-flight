---
name: Support Issue
about: 'See [PX4 Discuss](http://discuss.px4.io/) for questions about using PX4. '
title: ''
labels: ''
assignees: ''

---

We use GitHub issues only to discuss PX4 Avoidance bugs and new features. For
questions about using PX4 or related components, please use [PX4 Discuss](http://discuss.px4.io/).

Thanks!
